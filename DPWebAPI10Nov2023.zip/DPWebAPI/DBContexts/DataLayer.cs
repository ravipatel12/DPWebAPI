﻿using DPWebAPI.DBContexts;
using DPWebAPI.Entities;
using Humanizer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NuGet.Configuration;
using System.Data.SqlTypes;
using System.Data;
using System.Reflection.Metadata;
using System.Xml.Linq;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using System.Threading;
using System.Configuration;

namespace DPWebAPI.DBContexts
{
    public class DataLayer
    {
        
        
        //public DataLayer(ApplicationDBContext dbContext)
        //{
        //    _dbContext = dbContext;
        //}
        
    }
}
